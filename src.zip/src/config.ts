export const API_BASE_URL =
  process.env.EXPO_PUBLIC_API_BASE_URL ?? "https://lingua-audio-embedder.fly.dev";

export const STT_BASE_URL =
  process.env.EXPO_PUBLIC_STT_BASE_URL ?? "https://stt-service.fly.dev";